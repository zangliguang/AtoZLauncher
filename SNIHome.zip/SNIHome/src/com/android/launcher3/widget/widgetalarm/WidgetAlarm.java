package com.android.launcher3.widget.widgetalarm;

import android.appwidget.AppWidgetProvider;
import android.content.Context;

public class WidgetAlarm extends AppWidgetProvider {
    @Override
    public void onEnabled(Context context) {
        super.onEnabled(context);
    }
    @Override
    public void onDisabled(Context context) {
        super.onDisabled(context);
    }
}
