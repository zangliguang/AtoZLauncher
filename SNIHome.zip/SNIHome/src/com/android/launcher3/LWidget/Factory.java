package com.android.launcher3.LWidget;

import java.lang.reflect.Constructor;

import android.content.Context;
import android.view.LayoutInflater;

import com.suning.lotus.imps.data.client.UserDataServiceInterface;

public class Factory {

    public static IControl createLWidgetInstance(Context ctx,
                                    LayoutInflater inflater,
                                    String className)
    {
        Class<?> lwidget = null;
        try
        {
            lwidget = Class.forName(className);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        IControl ctrl = null;
        Constructor<?> cons[] = lwidget.getConstructors();
        try
        {
            ctrl = (IControl) cons[0].newInstance(ctx,  inflater);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return ctrl;

    }

}
