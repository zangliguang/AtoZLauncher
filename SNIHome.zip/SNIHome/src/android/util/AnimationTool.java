﻿package android.util;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.TranslateAnimation;
public class AnimationTool {
    // 创建移动动画
    public static TranslateAnimation createTranslateAnimation(float fromXDelta,
            float toXDelta, float fromYDelta, float toYDelta, long duration,
            int repeatCount, Interpolator interpolator,boolean setFillAfter) {
        TranslateAnimation animation = new TranslateAnimation(fromXDelta,
                toXDelta, fromYDelta, toYDelta);
        animation.setDuration(duration);// 设置动画持续时间
        animation.setRepeatCount(repeatCount);// 设置重复次数
        animation.setInterpolator(interpolator);
        animation.setFillAfter(setFillAfter);
        return animation;
    }
}
