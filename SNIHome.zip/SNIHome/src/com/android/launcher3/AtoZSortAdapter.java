
package com.android.launcher3;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.SectionIndexer;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * 臧黎光 2014年7月31日 上午10:24:26 AtoZ排序listview的adapter
 */
@SuppressLint("NewApi")
public class AtoZSortAdapter extends BaseAdapter implements SectionIndexer {
    private List<ArrayList<AppInfo>> list = null;
    private Context mContext;
    private View dragtView;
    public AtoZSortAdapter(Context mContext, List<ArrayList<AppInfo>> all) {
        this.mContext = mContext;
        this.list = all;
    }
    /**
     * 当ListView数据发生变化时,调用此方法来更新ListView
     * @param list
     */
    public void updateListView(List<ArrayList<AppInfo>> list) {
        this.list = list;
        notifyDataSetChanged();
    }

    public int getCount() {
        return this.list.size();
    }

    public Object getItem(int position) {
        return list.get(position);
    }

    public long getItemId(int position) {
        return position;
    }

    public View getView(final int position, View view, ViewGroup arg2) {
        ViewHolder viewHolder = null;
        final ArrayList<AppInfo> mContent = list.get(position);
        if (view == null) {
            viewHolder = new ViewHolder();
            view = LayoutInflater.from(mContext).inflate(R.layout.atoz_item, null);
            viewHolder.tvLetter = (TextView) view.findViewById(R.id.catalog);
            viewHolder.tvGridView = (GridView) view.findViewById(R.id.gridview);
            viewHolder.tvGridView.setAdapter(new AtoZGridViewAdapter(mContext, mContent));
            view.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) view.getTag();
        }
        viewHolder.tvLetter.setText(AtoZAppComparator.getSortLetters(mContent.get(0).title.toString()));
        ((AtoZGridViewAdapter) viewHolder.tvGridView.getAdapter()).updata(mContent);
        return view;
    }

    final static class ViewHolder {
        TextView tvLetter;
        GridView tvGridView;
    }
    /**
     * 根据ListView的当前位置获取分类的首字母的Char ascii值
     */
    public int getSectionForPosition(int position) {
        return AtoZAppComparator.getSortLetters(list.get(position).get(0).title.toString()).charAt(0);
    }

    /**
     * 根据分类的首字母的Char ascii值获取其第一次出现该首字母的位置
     */
    public int getPositionForSection(int section) {
        for (int i = 0; i < getCount(); i++) {
            String sortStr = AtoZAppComparator.getSortLetters(list.get(i).get(0).title.toString());
            char firstChar = sortStr.toUpperCase().charAt(0);
            if ((int) firstChar == section) {
                return i;
            }
        }
        return -1;
    }

    /**
     * 提取英文的首字母，非英文字母用#代替。
     * @param str
     * @return
     */
    private String getAlpha(String str) {
        String sortStr = str.trim().substring(0, 1).toUpperCase();
        // 正则表达式，判断首字母是否是英文字母
        if (sortStr.matches("[A-Z]")) {
            return sortStr;
        } else {
            return "#";
        }
    }
    @Override
    public Object[] getSections() {
        return null;
    }
    public void updateDateChange(List<ArrayList<AppInfo>> mAppLists) {
        this.list=mAppLists;
        notifyDataSetChanged();
    }
}
