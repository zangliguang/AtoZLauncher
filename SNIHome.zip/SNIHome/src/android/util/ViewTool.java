﻿package android.util;
import com.android.launcher3.model.ViewScale;
import android.view.View;
public class ViewTool {
    public static ViewScale getViewMeasuredWidthAndHeight(View v) {
        ViewScale vs = new ViewScale();
        int w = View.MeasureSpec.makeMeasureSpec(0,
                View.MeasureSpec.UNSPECIFIED);
        int h = View.MeasureSpec.makeMeasureSpec(0,
                View.MeasureSpec.UNSPECIFIED);
        v.measure(w, h);
        vs.height = v.getMeasuredHeight();
        vs.width = v.getMeasuredWidth();
        return vs;
    }
}
