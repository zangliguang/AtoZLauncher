
package com.android.launcher3;

import android.content.pm.PackageManager;

import java.util.Comparator;

/**
 * 臧黎光 2014年7月31日 上午10:29:14 app 比较
 */
public class AtoZAppComparator implements Comparator<AppInfo> {

    public int compare(AppInfo o1, AppInfo o2) {
        if (getSortLetters(o1.title.toString()).equals("@")
                || getSortLetters(o2.title.toString()).equals("#")) {
            return -1;
        } else if (getSortLetters(o1.title.toString()).equals("#")
                || getSortLetters(o2.title.toString()).equals("@")) {
            return 1;
        } else {
            return getSortLetters(o1.title.toString()).compareTo(getSortLetters(o2.title.toString()));
        }
    }

    public static String getSortLetters(String str) {
        String sortString = AtoZPinyin.getPinYinHeadChar(str).substring(0, 1).toUpperCase();
        // 正则表达式，判断首字母是否是英文字母
        if (sortString.matches("[A-Z]")) {
            return sortString.toUpperCase();
        } else {
            return "#";
        }

    }

    String str = "";

}
