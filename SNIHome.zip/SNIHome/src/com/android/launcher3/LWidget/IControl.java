﻿package com.android.launcher3.LWidget;
import com.android.launcher3.CellLayout;
import com.android.launcher3.model.Position;
import com.android.launcher3.LauncherAppLWidgetInfo;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.RelativeLayout;
public abstract class IControl {
    public abstract boolean isRunnable(String identity);
    public abstract View createView(Object data,
            LauncherAppLWidgetInfo lWidgetInfo, CellLayout cl);
    public abstract void release();
    protected Position getPositionByCell(LauncherAppLWidgetInfo lwidget,
            CellLayout cl, int clickRegionWidth, int clickRegionHeight) {
        int cellWidth = cl.getCellWidth();
        int cellheight = cl.getCellHeight();
        Position pos = new Position();
        float cellX = (float) (Float.parseFloat(String.valueOf(lwidget.cellX)) + lwidget.spanX / 10.0);
        float cellY = (float) (Float.parseFloat(String.valueOf(lwidget.cellY)) + lwidget.spanY / 10.0);
        pos.left = (int) (cellWidth * (cellX + 0.5) - clickRegionWidth / 2);
        pos.top = (int) (cellheight * (cellY + 0.5) - clickRegionHeight / 2);
        return pos;
    }
    // 针对不同动画坐标算法，允许子类重写该方法
    protected Position getPositionByCell(LauncherAppLWidgetInfo lwidget,
            CellLayout cl, RelativeLayout rl) {
        int cellWidth = cl.getCellWidth();
        int cellheight = cl.getCellHeight();
        Position pos = new Position();
        float cellX = (float) (Float.parseFloat(String.valueOf(lwidget.cellX)) + lwidget.spanX / 10.0);
        float cellY = (float) (Float.parseFloat(String.valueOf(lwidget.cellY)) + lwidget.spanY / 10.0);
        int w = View.MeasureSpec.makeMeasureSpec(0,
                View.MeasureSpec.UNSPECIFIED);
        int h = View.MeasureSpec.makeMeasureSpec(0,
                View.MeasureSpec.UNSPECIFIED);
        rl.measure(w, h);
        int height = rl.getMeasuredHeight();
        int width = rl.getMeasuredWidth();
        // Log.e("IControl", "cellWidth " + cellWidth + " cellheight "
        // + cellheight + " arc-height:" + height + " arc-width:" + width);
        pos.left = (int) (cellWidth * (cellX + 0.5) - width / 2);
        pos.top = (int) (cellheight * (cellY + 0.5) - height / 2);
        return pos;
    }
}
