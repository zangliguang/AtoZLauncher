package com.android.launcher3.widget.widgettimer;

import java.util.Calendar;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.text.format.DateFormat;
import android.util.Log;
import android.widget.RemoteViews;

import com.android.launcher3.R;

public class WidgetTimer extends AppWidgetProvider {

    protected static final String TAG = "WidgetTimer";

    private static boolean mRegistered = false;

    private final static String M12 = "h:mm";
    private final static String M24 = "kk:mm";
    private final static String WEEK[] = { "日", "一", "二", "三", "四", "五", "六" };

    private static final int WIDGET_CLOCK_TEXT_SIZE = 200;
    private static final int WIDGET_DAY_TEXT_SIZE = 60;

    @Override
    public void onEnabled(Context context) {
        super.onEnabled(context);
        Log.i(TAG, "enter onEnabled");
    }
    @Override
    public void onDisabled(Context context) {
        super.onDisabled(context);
    }

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        super.onUpdate(context, appWidgetManager, appWidgetIds);
        Log.i(TAG, "enter onUpdate");
        updateWidget(context);

        if (mRegistered == false) {
            IntentFilter filter = new IntentFilter();
            filter.addAction(Intent.ACTION_TIME_TICK);
            filter.addAction(Intent.ACTION_TIME_CHANGED);
            filter.addAction(Intent.ACTION_TIMEZONE_CHANGED);
            context.getApplicationContext().registerReceiver(mReceiver, filter);
            mRegistered = true;
        }
    }

    private BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if ((action == Intent.ACTION_TIME_TICK) || (action == Intent.ACTION_TIME_CHANGED) ||
                (action == Intent.ACTION_TIMEZONE_CHANGED)) {
                Log.i(TAG, "action=" + action);
                updateWidget(context);
            }
        }
    };

    private void updateWidget(Context context) {
        Log.i(TAG, "enter updateWidget");
        AppWidgetManager awm = AppWidgetManager.getInstance(context);;
        ComponentName provider = new ComponentName(context, WidgetTimer.class);
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widgettimer);
        Typeface tf = Typeface.createFromAsset(context.getAssets(), "fonts/KozGoProEL.ttf");

        String format = android.text.format.DateFormat.is24HourFormat(context) ? M24 : M12;
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        CharSequence newTime = DateFormat.format(format, calendar);
        String day = (calendar.get(Calendar.MONTH) + 1) + "月" + (calendar.get(Calendar.DAY_OF_MONTH))
                + "日" + " 星期" + WEEK[((calendar.get(Calendar.DAY_OF_WEEK)) - 1)];

        Paint textPaint = new Paint();
        textPaint.setAntiAlias(true);
        textPaint.setSubpixelText(true);
        textPaint.setTypeface(tf);
        textPaint.setColor(Color.WHITE);
        textPaint.setTextSize(WIDGET_CLOCK_TEXT_SIZE);
        textPaint.setStyle(Paint.Style.FILL);
        textPaint.setTextAlign(Align.LEFT);

        Rect bound = new Rect();
        String text = newTime.toString();
        textPaint.getTextBounds(text, 0, text.length(), bound);

        Bitmap bitmapClock = Bitmap.createBitmap(bound.width(), bound.height(), Bitmap.Config.ARGB_8888);
        Canvas canvasClock = new Canvas(bitmapClock);
        canvasClock.drawText(text, -bound.left, -bound.top, textPaint);
        views.setImageViewBitmap(R.id.timer_clock, bitmapClock);

        textPaint.setTextSize(WIDGET_DAY_TEXT_SIZE);
        text = day;
        textPaint.getTextBounds(text, 0, text.length(), bound);

        Bitmap bitmapDay = Bitmap.createBitmap(bound.width(), bound.height(), Bitmap.Config.ARGB_8888);
        Canvas canvasDay = new Canvas(bitmapDay);
        canvasDay.drawText(text, -bound.left, -bound.top, textPaint);
        views.setImageViewBitmap(R.id.timer_day, bitmapDay);

        awm.updateAppWidget(provider, views);
    }
}
