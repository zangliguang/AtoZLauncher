package com.android.launcher3.LWidget;

import java.util.ArrayList;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract.PhoneLookup;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.android.launcher3.CellLayout;
import com.android.launcher3.LauncherAppLWidgetInfo;
import com.android.launcher3.LauncherModel;
import com.android.launcher3.R;
import com.android.launcher3.model.Position;
import com.capricorn.AngleRayMenu;
import com.suning.lotus.imps.data.client.UserDataServiceInterface;
import com.suning.lotus.imps.data.client.datamodel.ContactInfo;

public class FavouriteContactCtrl extends IControl {
    protected static final String TAG = "FavouriteContactCtrl";
    private LayoutInflater inflater;
    private final Context ctx;

    public FavouriteContactCtrl(Context ctx, LayoutInflater inflater) {
        this.inflater = inflater;
        this.ctx = ctx;
    }

    @Override
    public boolean isRunnable(String identity) {
        return true;
    }

    @Override
    public void release() {
        this.inflater = null;
    }

    @Override
    public View createView(Object data, LauncherAppLWidgetInfo lWidgetInfo, CellLayout cl) {
         UserDataServiceInterface usservice = LauncherModel.getUserDataService();
         ArrayList<ContactInfo> contacts = usservice.getUserInstantContacts();
//        ArrayList<ContactInfo> contacts = new ArrayList<ContactInfo>();
//        ContactInfo contactInfo;
//        for (int i = 0; i < 4; i++) {
//            contactInfo = new ContactInfo();
//            contactInfo.setPhoneNumber("18616687115");
//            contactInfo.setDuration(100);
//            contactInfo.setCount(5);
//            contacts.add(contactInfo);
//        }
        if (contacts == null || contacts.size() <= 0)
            return null;
        RelativeLayout arc_main = (RelativeLayout) inflater.inflate(R.layout.angle_ray_main, null);
        RelativeLayout.LayoutParams lp_arc_main = new RelativeLayout.LayoutParams(android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT);
        final ArrayList<ContactInfo> contactList = contacts;
        AngleRayMenu mArcMenu = (AngleRayMenu) arc_main.findViewById(R.id.angle_ray_menu);
        final int itemCount = Math.min(contactList.size(), 6);
        TextView textView;
        for (int i = 0; i < itemCount; i++) {
            ContactInfo c = contactList.get(i);
            if (c != null && c.getPhoneNumber() != null) {
                textView = new TextView(ctx);
                textView.setText(queryContactName(c.getPhoneNumber()));
                final int position = i;
                mArcMenu.addItem(textView, new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Log.i(TAG, "click position: " + position);
                        Uri uri = Uri.parse("tel:" + contactList.get(position).getPhoneNumber());
                        Intent intent = new Intent();
                        intent.setAction(Intent.ACTION_CALL);
                        intent.setData(uri);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        ctx.startActivity(intent);
                    }
                });
            }
        }
        Position pos = getPositionByCell(lWidgetInfo, cl, arc_main);
        lp_arc_main.setMargins(pos.left, pos.top, 0, 0);
        arc_main.setLayoutParams(lp_arc_main);
        return arc_main;
    }

    /**
     * 根据号码查询联系人姓名
     * @param number
     * @return
     */
    private String queryContactName(String number) {
        Cursor c = ctx.getContentResolver().query(Uri.withAppendedPath(PhoneLookup.CONTENT_FILTER_URI, number), new String[] { PhoneLookup._ID, PhoneLookup.NUMBER, PhoneLookup.DISPLAY_NAME, PhoneLookup.TYPE, PhoneLookup.LABEL }, null, null, null);
        String contact_name = null;
        if (c.getCount() > 0) {
            c.moveToFirst();
            contact_name = c.getString(2);
        }
        c.close();
        return contact_name;
    }
}
