﻿package android.util;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;
import android.provider.ContactsContract.PhoneLookup;
public class PhoneTool {
    public static void startDailingPhoneActivity(Context ctx, String phone) {
        Intent phoneIntent = new Intent("android.intent.action.CALL",
                Uri.parse("tel:" + phone));
        phoneIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        ctx.startActivity(phoneIntent);
    }
    public static String getContactNameByNumber(String number, Context ctx) {
        Cursor c = ctx.getContentResolver().query(
                Uri.withAppendedPath(PhoneLookup.CONTENT_FILTER_URI, number),
                new String[] { PhoneLookup._ID, PhoneLookup.NUMBER,
                        PhoneLookup.DISPLAY_NAME, PhoneLookup.TYPE,
                        PhoneLookup.LABEL }, null, null, null);
        String contact_name = null;
        if (c.getCount() > 0) {
            c.moveToFirst();
            contact_name = c.getString(2);
        }
        c.close();
        return contact_name;
    }
}
