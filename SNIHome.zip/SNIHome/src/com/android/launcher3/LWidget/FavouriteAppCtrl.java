﻿package com.android.launcher3.LWidget;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.util.AppInfoParser;
import android.util.Log;
import android.util.PictureTool;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import com.android.launcher3.CellLayout;
import com.android.launcher3.LauncherAppLWidgetInfo;
import com.android.launcher3.LauncherModel;
import com.android.launcher3.R;
import com.android.launcher3.model.Position;
import com.capricorn.ArcMenu;
import com.suning.lotus.imps.data.client.UserDataServiceInterface;
import com.suning.lotus.imps.data.client.datamodel.AppInfo;
import com.suning.lotus.imps.data.client.datamodel.CardInfo;
public class FavouriteAppCtrl extends IControl {
    private LayoutInflater inflater;
    private final Context ctx;
    public FavouriteAppCtrl(Context ctx, LayoutInflater inflater) {
        this.inflater = inflater;
        this.ctx = ctx;
    }
    @Override
    public boolean isRunnable(String identity) {
        return true;
    }
    @Override
    public void release() {
        this.inflater = null;
        // this.ctx = null;
    }
    @Override
    public View createView(Object data, LauncherAppLWidgetInfo lWidgetInfo,
            CellLayout cl) {
        UserDataServiceInterface usservice = LauncherModel.getUserDataService();
        ArrayList<AppInfo> appdata = usservice.getUserInstantAppUseage();
        if (appdata == null || appdata.size() <= 0)
            return null;
        Collections.sort(appdata, new AppUsageDesc());
        // for(String s:bun.getStringArrayList("result"))
        // {
        // Log.e(TAG, "most app data-" + s);
        // }
        // add child to parent container
        RelativeLayout arc_main = (RelativeLayout) inflater.inflate(
                R.layout.arc_main, null);
        RelativeLayout.LayoutParams lp_arc_main = new RelativeLayout.LayoutParams(
                android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT,
                android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT);
        final ArrayList<AppInfo> appList = appdata;
        ArcMenu mArcMenu = (ArcMenu) arc_main.findViewById(R.id.arc_menu);
        final int itemCount = Math.min(appList.size(), 6);
        for (int i = 0; i < itemCount; i++) {
            ApplicationInfo appInfo = AppInfoParser.getApplicationInfo(ctx,
                    appList.get(i).getAppName());
            if (appInfo != null) {
                ImageView icon = new ImageView(ctx);
                Bitmap bp = PictureTool.toRoundBitmap(PictureTool
                        .drawableToBitmap(appInfo.loadIcon(ctx
                                .getPackageManager())));
                icon.setImageBitmap(bp);
                // icon.setImageDrawable(appInfo.loadIcon(ctx.getPackageManager()));
                final int position = i;
                mArcMenu.addItem(icon, new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        int boundaryIndex = appList.get(position).getAppName()
                                .indexOf("/");
                        Intent intent;
                        if (boundaryIndex < 0) {
                            intent = ctx.getPackageManager()
                                    .getLaunchIntentForPackage(
                                            appList.get(position).getAppName());
                        } else {
                            intent = ctx
                                    .getPackageManager()
                                    .getLaunchIntentForPackage(
                                            appList.get(position)
                                                    .getAppName()
                                                    .substring(0, boundaryIndex));
                        }
                        ctx.startActivity(intent);
                    }
                });
            }
        }
        Position pos = getPositionByCell(lWidgetInfo, cl, arc_main);
        lp_arc_main.setMargins(pos.left, pos.top, 0, 0);
        arc_main.setLayoutParams(lp_arc_main);
        // ((ViewGroup) lWidgetContainer).addView(arc_main);
        return arc_main;
    }
    public class AppUsageDesc implements Comparator {
        public int compare(Object arg0, Object arg1) {
            AppInfo user0 = (AppInfo) arg0;
            AppInfo user1 = (AppInfo) arg1;
            if (user0.getDuration() < user1.getDuration()) {
                return 1;
            } else if (user0.getDuration() == user1.getDuration()) {
                return 0;
            } else {
                return -1;
            }
        }
    }
    private ArrayList<String> getSubAppsOrderByAsc(CardInfo c) {
        ArrayList<String> appInfo = c.getChildAppInfo();
        ArrayList<Integer> appInfoOrder = c.getChildAppInfoOrder();
        int tempAppInfoOrder;
        String tempAppInfo;
        if (appInfoOrder != null && appInfoOrder.size() > 0) {
            for (int i = 0; i < appInfoOrder.size() - 1; i++) {
                for (int j = i + 1; j < appInfoOrder.size(); j++) {
                    if (appInfoOrder.get(i) > appInfoOrder.get(j)) {
                        tempAppInfoOrder = appInfoOrder.get(i);
                        appInfoOrder.set(i, appInfoOrder.get(j));
                        appInfoOrder.set(j, tempAppInfoOrder);
                        tempAppInfo = appInfo.get(i);
                        appInfo.set(i, appInfo.get(j));
                        appInfo.set(j, tempAppInfo);
                    }
                }
            }
        }
        return appInfo;
    }
}
