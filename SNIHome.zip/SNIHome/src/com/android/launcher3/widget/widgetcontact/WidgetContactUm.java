package com.android.launcher3.widget.widgetcontact;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

import com.android.launcher3.R;

public class WidgetContactUm extends AppWidgetProvider {
    @Override
    public void onEnabled(Context context) {
        super.onEnabled(context);
    }
    @Override
    public void onDisabled(Context context) {
        super.onDisabled(context);
    }

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager,
            int[] appWidgetIds)
    {
        Intent intent = new Intent();
        intent.setAction("com.android.contacts.action.LIST_STREQUENT");

        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, intent, 0);
        RemoteViews remoteViews  = new RemoteViews(context.getPackageName(),R.layout.widgetcontact_um);

        remoteViews.setOnClickPendingIntent(R.id.contact_widget, pendingIntent);

        appWidgetManager.updateAppWidget(appWidgetIds, remoteViews);
    }
}
