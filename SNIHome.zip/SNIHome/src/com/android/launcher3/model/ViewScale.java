﻿package com.android.launcher3.model;
public class ViewScale {
    public int width;
    public int height;

}
