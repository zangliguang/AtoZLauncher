package com.android.launcher3.widget.widgetmessage;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.RemoteViews;

import com.android.launcher3.R;

public class WidgetMessageUm extends AppWidgetProvider {
    @Override
    public void onEnabled(Context context) {
        super.onEnabled(context);
    }
    @Override
    public void onDisabled(Context context) {
        super.onDisabled(context);
    }
    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager,
            int[] appWidgetIds)
    {
        Intent intent = new Intent();

        intent.setAction(Intent.ACTION_MAIN);
        intent.addCategory("android.intent.category.APP_MESSAGING");
//        intent.setAction(Intent.ACTION_VIEW);
//        intent.setType("vnd.android-dir/mms-sms");


        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, intent, 0);
        RemoteViews remoteViews  = new RemoteViews(context.getPackageName(),R.layout.widgetmessage_um);

        remoteViews.setOnClickPendingIntent(R.id.message_widget, pendingIntent);

        appWidgetManager.updateAppWidget(appWidgetIds, remoteViews);
    }
}
