package com.android.launcher3.model;

public class Position {
    public int left = 0;
    public int top = 0;
}
