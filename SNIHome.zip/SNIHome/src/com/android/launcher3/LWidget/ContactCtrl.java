﻿package com.android.launcher3.LWidget;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.provider.Contacts;
import android.util.AnimationTool;
import android.util.AppInfoParser;
import android.util.Log;
import android.util.PhoneTool;
import android.util.PictureTool;
import android.util.ScreenTool;
import android.util.ViewTool;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnticipateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.OvershootInterpolator;
import android.view.animation.TranslateAnimation;
import android.view.animation.Animation.AnimationListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import android.widget.Toast;
import com.android.launcher3.CellLayout;
import com.android.launcher3.DynamicGrid;
import com.android.launcher3.Launcher;
import com.android.launcher3.LauncherAppLWidgetInfo;
import com.android.launcher3.LauncherModel;
import com.android.launcher3.R;
import com.android.launcher3.LWidget.FavouriteAppCtrl.AppUsageDesc;
import com.android.launcher3.model.Position;
import com.android.launcher3.model.ViewScale;
import com.capricorn.ArcMenu;
import com.suning.lotus.imps.data.client.UserDataServiceInterface;
import com.suning.lotus.imps.data.client.datamodel.AppInfo;
import com.suning.lotus.imps.data.client.datamodel.CardInfo;
import com.suning.lotus.imps.data.client.datamodel.ContactInfo;
public class ContactCtrl extends IControl {
    private LayoutInflater inflater;
    private final Context ctx;
    private RightTransAnimationState rightTransAnimationState = RightTransAnimationState.expand;
    private DataState dateState = DataState.noData;
    private enum DataState {
        haveData, noData
    }
    public ContactCtrl(Context ctx, LayoutInflater inflater) {
        this.inflater = inflater;
        this.ctx = ctx;
    }
    @Override
    public boolean isRunnable(String identity) {
        return true;
    }
    @Override
    public void release() {
        this.inflater = null;
        // this.ctx = null;
    }
    // 右移动画
    private TranslateAnimation createRightTranslateAnimation(ViewScale vs,
            CellLayout cl, Interpolator interpolator, int itemsSize) {
        long duration = 0l;
        duration = itemsSize * 1000 / 4;
        return AnimationTool.createTranslateAnimation(0,
                vs.width - cl.getCellWidth() * 2, 0, 0, duration, 0,
                new DecelerateInterpolator(1.7f), false);
    }
    // 左移动画
    private TranslateAnimation createLeftTranslateAnimation(ViewScale vs,
            CellLayout cl, Interpolator interpolator, int itemsSize) {
        long duration = 0l;
        duration = itemsSize * 1000 / 4;
        return AnimationTool.createTranslateAnimation(0, cl.getCellWidth() * 2
                - vs.width, 0, 0, duration, 0,
                new DecelerateInterpolator(1.7f), false);
    }
    private AlphaAnimation createAlphaFrom0To100Animation(float fromAlpha,
            float toAlpha, long duration) {
        AlphaAnimation alphaAnimation = new AlphaAnimation(fromAlpha, toAlpha);
        alphaAnimation.setDuration(duration);
        return alphaAnimation;
    }
    private String getPhoneName(ContactInfo conatctInfo) {
        if (dateState == DataState.haveData) {
            return PhoneTool.getContactNameByNumber(
                    conatctInfo.getPhoneNumber(), ctx);
        } else
            return "laucher";
    }
    @Override
    public View createView(Object data, LauncherAppLWidgetInfo lWidgetInfo,
            final CellLayout cl) {
        Interpolator decelerateInterpolator = new DecelerateInterpolator(1.7f);
        UserDataServiceInterface usservice = LauncherModel.getUserDataService();
        ArrayList<ContactInfo> contactInfoList = usservice
                .getUserInstantContacts();
        if (contactInfoList == null || contactInfoList.size() <= 0) {
            contactInfoList = new ArrayList<ContactInfo>();
            ContactInfo c1 = new ContactInfo();
            c1.setDuration(1000);
            c1.setPhoneNumber("13681254384");
            contactInfoList.add(c1);
            ContactInfo c2 = new ContactInfo();
            c2.setDuration(1000);
            c2.setPhoneNumber("13681254384");
            contactInfoList.add(c2);
            ContactInfo c3 = new ContactInfo();
            c3.setDuration(1000);
            c3.setPhoneNumber("13681254384");
            contactInfoList.add(c3);
            ContactInfo c11 = new ContactInfo();
            c11.setDuration(1000);
            c11.setPhoneNumber("13681254384");
            contactInfoList.add(c11);
        } else {
            dateState = DataState.haveData;
        }
        Collections.sort(contactInfoList, new ContactUsageDesc());
        final RelativeLayout arc_main = (RelativeLayout) inflater.inflate(
                R.layout.contact_main, null);
        // 联系人列表
        final LinearLayout arc_item = (LinearLayout) inflater.inflate(
                R.layout.contact_item, null);
        final ArrayList<ContactInfo> contactInfoListFinal = contactInfoList;
        for (int i = 0; i < Math.min(contactInfoList.size(), 4); i++) {
            final int index = i;
            String name = getPhoneName(contactInfoList.get(i));
            if (name != null && name.trim().length() > 0)
                arc_item.addView(getTextView("tvContact" + i, name,
                        new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                PhoneTool.startDailingPhoneActivity(ctx,
                                        contactInfoListFinal.get(index)
                                                .getPhoneNumber());
                            }
                        }));
        }
        arc_item.addView(getClickImageView("ivClickRegion", cl, null,
                R.drawable.sn_smart_ic_contact_coffee));
        RelativeLayout.LayoutParams lp_arc_main = new RelativeLayout.LayoutParams(
                cl.getCellWidth() * 2, cl.getCellHeight() * 2);
        Position pos = getPositionByCell(lWidgetInfo, cl,
                cl.getCellWidth() * 2, cl.getCellHeight() * 2);
        lp_arc_main.setMargins(pos.left, pos.top, 0, 0);
        arc_main.setLayoutParams(lp_arc_main);
        arc_main.addView(arc_item);
        final ViewScale vs = ViewTool.getViewMeasuredWidthAndHeight(arc_item);
        final TranslateAnimation rightAnimation = createRightTranslateAnimation(
                vs, cl, decelerateInterpolator, contactInfoList.size());
        final TranslateAnimation leftAnimation = createLeftTranslateAnimation(
                vs, cl, decelerateInterpolator, contactInfoList.size());
        ImageView ivClickRegion = (ImageView) arc_item
                .findViewWithTag("ivClickRegion");
        ivClickRegion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (dateState == DataState.haveData) {
                    if (rightTransAnimationState == RightTransAnimationState.expand) {
                        RelativeLayout.LayoutParams lp_arc_main = (LayoutParams) arc_main
                                .getLayoutParams();
                        lp_arc_main.width = ScreenTool.getScreenWidth(ctx);
                        arc_main.setLayoutParams(lp_arc_main);
                        arc_item.setVisibility(View.GONE);
                        arc_item.setAnimation(rightAnimation);
                        rightAnimation.startNow();
                    } else {
                        arc_item.setVisibility(View.GONE);
                        arc_item.setAnimation(leftAnimation);
                        leftAnimation.startNow();
                    }
                } else {
                    Intent intent = new Intent();
                    intent.setAction(Intent.ACTION_VIEW);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    intent.setData(Contacts.People.CONTENT_URI);
                    ctx.startActivity(intent);
                }
            }
        });
        rightAnimation.setAnimationListener(new AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
            }
            @Override
            public void onAnimationRepeat(Animation animation) {
            }
            @Override
            public void onAnimationEnd(Animation animation) {
                if (rightTransAnimationState == RightTransAnimationState.expand) {
                    RelativeLayout.LayoutParams lp_arc_item = (LayoutParams) arc_item
                            .getLayoutParams();
                    lp_arc_item.height = cl.getCellHeight() * 2;
                    lp_arc_item.setMargins(0, 0, 0, 0);
                    arc_item.setLayoutParams(lp_arc_item);
                    arc_item.setVisibility(View.VISIBLE);
                    arc_item.clearAnimation();
                    arc_main.requestLayout();
                    rightTransAnimationState = RightTransAnimationState.shrink;
                }
            }
        });
        leftAnimation.setAnimationListener(new AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
            }
            @Override
            public void onAnimationRepeat(Animation animation) {
            }
            @Override
            public void onAnimationEnd(Animation animation) {
                RelativeLayout.LayoutParams lp_arc_item = (LayoutParams) arc_item
                        .getLayoutParams();
                lp_arc_item.height = cl.getCellHeight() * 2;
                lp_arc_item.setMargins(cl.getCellWidth() * 2 - vs.width, 0, 0,
                        0);
                arc_item.setLayoutParams(lp_arc_item);
                arc_item.setVisibility(View.VISIBLE);
                arc_item.clearAnimation();
                arc_main.requestLayout();
                rightTransAnimationState = RightTransAnimationState.expand;
            }
        });
        // arc_main.setBackgroundColor(Color.GRAY);
        RelativeLayout.LayoutParams lp_arc_item = (LayoutParams) arc_item
                .getLayoutParams();
        // lp_arc_item.height = cl.getCellHeight() * 2;
        lp_arc_item.setMargins(cl.getCellWidth() * 2 - vs.width, 0, 0, 0);
        arc_item.setLayoutParams(lp_arc_item);
        return arc_main;
    }
    private enum RightTransAnimationState {
        expand, shrink
    }
    private ImageView getClickImageView(String tag, CellLayout cellLayout,
            final View.OnClickListener cl, int resid) {
        ImageView iv = new ImageView(ctx);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                cellLayout.getCellWidth() * 2, cellLayout.getCellHeight() * 2);
        lp.gravity = Gravity.CENTER_VERTICAL | Gravity.CENTER_HORIZONTAL;
        iv.setLayoutParams(lp);
        iv.setTag(tag);
        iv.setImageResource(resid);
        if (cl != null)
            iv.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(final View viewClicked) {
                    if (cl != null) {
                        cl.onClick(viewClicked);
                    }
                }
            });
        // iv.setGravity(Gravity.CENTER_VERTICAL | Gravity.CENTER_HORIZONTAL);
        return iv;
    }
    private TextView getTextView(String tag, String content,
            final View.OnClickListener cl) {
        TextView tv = new TextView(ctx);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                DynamicGrid
                        .pxFromDp(60, ctx.getResources().getDisplayMetrics()),
                DynamicGrid
                        .pxFromDp(40, ctx.getResources().getDisplayMetrics()));
        lp.gravity = Gravity.CENTER_VERTICAL | Gravity.CENTER_HORIZONTAL;
        tv.setLayoutParams(lp);
        tv.setTag(tag);
        tv.setText(content);
        tv.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(final View viewClicked) {
                if (cl != null) {
                    cl.onClick(viewClicked);
                }
            }
        });
        // tv.setClickable(true);
        tv.setTextSize(15);
        tv.setTypeface(Typeface.create("宋体", Typeface.BOLD_ITALIC));
        tv.setGravity(Gravity.CENTER_VERTICAL | Gravity.CENTER_HORIZONTAL);
        return tv;
    }
    // 按电话duration降序
    public class ContactUsageDesc implements Comparator {
        public int compare(Object arg0, Object arg1) {
            ContactInfo user0 = (ContactInfo) arg0;
            ContactInfo user1 = (ContactInfo) arg1;
            if (user0.getDuration() < user1.getDuration()) {
                return 1;
            } else if (user0.getDuration() == user1.getDuration()) {
                return 0;
            } else {
                return -1;
            }
        }
    }
}
