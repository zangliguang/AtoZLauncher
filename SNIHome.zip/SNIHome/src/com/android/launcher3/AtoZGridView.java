
package com.android.launcher3;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.GridView;

/**
 * 臧黎光  2014年7月30日 下午4:45:18
 * AtoZ listview的item嵌套的自定义gridview
 * 满行后自动换行
 */
public class AtoZGridView extends GridView {
    public AtoZGridView(Context context) {
        super(context);
    }

    public AtoZGridView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public AtoZGridView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int heightSpec;

        if (getLayoutParams().height == LayoutParams.WRAP_CONTENT) {
            // The great Android "hackatlon", the love, the magic.
            // The two leftmost bits in the height measure spec have
            // a special meaning, hence we can't use them to describe height.
            heightSpec = MeasureSpec.makeMeasureSpec(
                    Integer.MAX_VALUE >> 2, MeasureSpec.AT_MOST);
        }
        else {
            // Any other height should be respected as is.
            heightSpec = heightMeasureSpec;
        }

        super.onMeasure(widthMeasureSpec, heightSpec);
    }
}
