
package com.android.launcher3;

import android.net.Uri;

/*
 * SN_ZX_BEGIN_END
 * javabean for TABLE_SCENE_THEME
 */
public class SceneTheme {
    private int sceneId;
    private int numberScreen;
    private Uri wallPaper;

    public int getSceneId() {
        return sceneId;
    }

    public void setSceneId(int sceneId) {
        this.sceneId = sceneId;
    }

    public Uri getWallPaper() {
        return wallPaper;
    }

    public void setWallPaper(Uri wallPaper) {
        this.wallPaper = wallPaper;
    }

    public int getNumberScreen() {
        return numberScreen;
    }

    public void setNumberScreen(int numberScreen) {
        this.numberScreen = numberScreen;
    }
}
