
package com.android.launcher3;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.android.launcher3.Launcher.State;

import java.util.ArrayList;
import java.util.List;

/**
 * 臧黎光 2014年7月30日 下午4:45:43 AtoZ listview的item嵌套的自定义gridview的adapter
 */
public class AtoZGridViewAdapter extends BaseAdapter {
    private List<AppInfo> list = null;
    private Context mContext;
    private View dragtView;


    public AtoZGridViewAdapter(Context mContext, ArrayList<AppInfo> mContent) {
        this.mContext = mContext;
        this.list = mContent;
        }

    @Override
    public int getCount() {
        return this.list.size();
    }

    @Override
    public Object getItem(int i) {
        return list.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @SuppressLint("NewApi")
    @Override
    public View getView(final int position, View view, ViewGroup arg2) {
        final AppInfo mContent = list.get(position);
        if (view == null) {
            view = LayoutInflater.from(mContext).inflate(R.layout.atoz_shortcut_item, null);
            view.setTag(mContent);
        }
        ((AtoZPageViewIcon) view).setText(mContent.title);
        ((AtoZPageViewIcon) view).setTextColor(Color.parseColor("#333333"));
        FastBitmapDrawable d = new FastBitmapDrawable(mContent.iconBitmap);
        d.setFilterBitmap(true);
        DisplayMetrics dm = new DisplayMetrics();
        //获取屏幕信息
        ((Activity) mContext).getWindowManager().getDefaultDisplay().getMetrics(dm);
        int screenWidth = dm.widthPixels;
        int with = (screenWidth/12*11)/7;//listview占屏宽的11/12，icon宽度为listview宽度的1/7(5个icon+6个间隔)
        d.setBounds(0, 0, with, with);
        ((AtoZPageViewIcon) view).setCompoundDrawables(null,d,null, null);
        //view.setup((Launcher)mContext,  new DragController((Launcher)mContext));
        ((AtoZPageViewIcon) view).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if(((Launcher) mContext).getmState() == State.APPS_ATOZ){
                    Intent intent = mContext.getPackageManager().getLaunchIntentForPackage(
                            mContent.componentName.getPackageName());
                    mContext.startActivity(intent);
                }
            }
        });

        ((AtoZPageViewIcon) view).setOnLongClickListener(new OnLongClickListener() {

            @Override
            public boolean onLongClick(final View v) {
               final Launcher mLauncher = (Launcher) mContext;
               //一旦状态修改为workspace，不再执行长按事件，保证长按或短按事件只在atoz状态执行
               if(mLauncher.getmState() == State.APPS_ATOZ){
                v.setTag(mContent);
                mLauncher.getWorkspace().onDragStartedWithItem(v);
                mLauncher.getWorkspace().beginDragShared(v, (DragSource) v);
                //SN_ZX_BEGIN:snap to non imps screen.
                if (mLauncher.getWorkspace().getCurrentPage() < mLauncher.getModel().getNumberImpsScreens()) {
                    mLauncher.getWorkspace().snapToPage(mLauncher.getModel().getNumberImpsScreens());
                }
                //SN_ZX_END
                v.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        // We don't enter spring-loaded mode if the drag has
                        // been cancelled
                        if (mLauncher.getDragController().isDragging()) {
                            // Reset the alpha on the dragged icon before we
                            // drag
                            v.refreshDrawableState();

                            // Go into spring loaded mode (must happen before we
                            // startDrag())
                            mLauncher.enterSpringLoadedDragMode();
                        }
                    }
                }, 150);
               }
                return false;
            }
        });
        return view;
    }

    public void updata(ArrayList<AppInfo> mContent) {
        list=mContent;
        notifyDataSetChanged();
    }

}
