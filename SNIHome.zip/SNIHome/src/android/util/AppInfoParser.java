package android.util;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager.NameNotFoundException;

public class AppInfoParser {

    public static ApplicationInfo getApplicationInfo(Context ctx, String pkgname)
    {
        ApplicationInfo info = null;
        try
        {
            int boundaryIndex = pkgname.indexOf("/");
            if (boundaryIndex < 0)
            {
                info = ctx.getPackageManager().getApplicationInfo(pkgname, 0);
            }
            else
            {
                info = ctx.getPackageManager().getApplicationInfo(pkgname.substring(0, boundaryIndex), 0);
            }
        }
        catch (NameNotFoundException e) {

        }
        return info;
    }
}
