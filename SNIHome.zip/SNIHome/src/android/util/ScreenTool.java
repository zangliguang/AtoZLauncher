﻿package android.util;
import android.content.Context;
import android.view.WindowManager;
public class ScreenTool {
    public static int getScreenWidth(Context ctx) {
        WindowManager mWm = (WindowManager) ctx
                .getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics DM = new DisplayMetrics();
        mWm.getDefaultDisplay().getMetrics(DM);
        return DM.widthPixels; // 屏幕宽（像素，如：480px）
    }
    public static int getScreenHeight(Context ctx) {
        WindowManager mWm = (WindowManager) ctx
                .getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics DM = new DisplayMetrics();
        mWm.getDefaultDisplay().getMetrics(DM);
        return DM.heightPixels; // 屏幕宽（像素，如：480px）
    }
}
